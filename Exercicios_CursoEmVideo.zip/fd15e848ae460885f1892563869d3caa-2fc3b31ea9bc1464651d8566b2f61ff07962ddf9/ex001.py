# fazer um programa que diga "Olá, Mundo!"
print('{} DESAFIO 01 {}'.format(('='*5), ('='*5)))
print('Olá, Mundo!')