# Fazer um programa que leia o nome e cumprimente a pessoa usando o nome dela
print('{} DESAFIO 02 {}'.format(('=*'5), ('='*5)))
nome = input('Digite o seu nome: ')
print('Estou feliz em conhece-lo, {}'.format(nome))
