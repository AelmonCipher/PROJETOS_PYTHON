# Fazer um programa que leia dois números e mostre a soma deles
print('{} DESAFIO 03 {}'.format(('='*5), ('='*5)))
n1 = int(input('Digite um numero: '))
n2 = int(input('Digite outro numero: '))
s = n1+n2
print('A soma de {} e {} vale {}'.format(n1, n2, s))
