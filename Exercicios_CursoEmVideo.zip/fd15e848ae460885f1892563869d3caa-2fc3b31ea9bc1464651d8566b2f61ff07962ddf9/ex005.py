# fazer um programa que mostre o sucessor e o antecessor
print('{} DESAFIO 05 {}'.format(('='*5), ('='*5)))
n1 = int(input('Digite um numero: '))
print('O sucessor de {} é igual a {}\nO antecessor de {} é igual {}'.format(n1, (n1+1), n1, (n1-1)))
