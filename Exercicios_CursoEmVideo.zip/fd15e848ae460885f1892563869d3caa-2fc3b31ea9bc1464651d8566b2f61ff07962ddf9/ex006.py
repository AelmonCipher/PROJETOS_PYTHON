# fazer um programa que mostra o dobro, triplo e a raiz quadrada
print('{} DESAFIO 06 {}'.format(('='*5), ('='*5)))
n1 = int(input('Digite um número: '))
print('O dobro de {} vale {}\nO triplo de {} vale {}\nA raiz quadrada de {} vale {:.2f}'.format(n1, (n1*2), n1, (n1*3), n1, pow(n1, (1/2))))
