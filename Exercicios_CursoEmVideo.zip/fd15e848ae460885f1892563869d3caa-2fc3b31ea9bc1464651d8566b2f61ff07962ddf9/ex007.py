# fazer um programa que mostre a média entre duas notas
print('{} DESAFIO 07 {}'.format(('='*5), ('='*5)))
n1 = float(input('Informe a primeira nota: '))
n2 = float(input('Informe a segunda nota: '))
print('A média entre {:.1f} e {:.1f} é igual a {:.1f}'.format(n1, n2, ((n1+n2)/2)))
