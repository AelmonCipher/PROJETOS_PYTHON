#Converter celsius para farenheit
print('{} DESAFIO 14 {}'.format(('='*5), ('='*5)))
celsius = float(input('Informe a temperatura em celsius para converter para Farenheit: '))
farenheit = (1.8*celsius)+32
print('{}°C é igual a {}°F'.format(celsius, farenheit))
