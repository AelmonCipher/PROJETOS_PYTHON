from math import trunc
print('{} DESAFIO 16 {}'.format(('='*5), ('='*5)))
num = float(input('Digite um numero: '))
print('A parte inteira de {} é {}'.format(num, (trunc(num))))
