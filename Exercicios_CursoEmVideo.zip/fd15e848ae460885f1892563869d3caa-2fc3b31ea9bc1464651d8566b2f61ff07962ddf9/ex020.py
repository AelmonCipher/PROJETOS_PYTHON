from random import shuffle
print('{} DESAFIO 20 {}'.format(('=' * 5), ('=' * 5)))
aluno1 = str(input('Qual o nome do primeiro aluno? '))
aluno2 = str(input('Qual o nome do segundo aluno? '))
aluno3 = str(input('Qual o nome do terceiro aluno? '))
aluno4 = str(input('Qual o nome do quarto aluno? '))
ordem = [aluno1, aluno2, aluno3, aluno4]
shuffle(ordem)
print('A ordem de apresentação será')
print(ordem)
