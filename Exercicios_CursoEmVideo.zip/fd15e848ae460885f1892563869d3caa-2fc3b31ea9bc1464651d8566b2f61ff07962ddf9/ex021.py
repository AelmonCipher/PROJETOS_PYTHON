print('{} DESAFIO 21 {}'.format(('='*5), ('='*5)))
import winsound
winsound.PlaySound('ex021', winsound.SND_ALIAS)
