print('{} DESAFIO 23 {}'.format(('='*5), ('='*5)))
#1) parte com string, da erro se digitar menos de 4 digitos
n = str(input('Informe um numero de 0 a 9999: '))
print('Unidade: {}\nDezena: {}\nCentena: {}\nMilhar: {}'.format(n[3], n[2], n[1], n[0]))
#1) usando metodo matemático, não apresenta erro usando menos de 4 digitos
print('{} DESAFIO 23 {}'.format(('='*5), ('='*5)))
n = int(input('Informe um numero de 0 a 9999: '))
u = n // 1 % 10
d = n // 10 % 10
c = n // 100 % 10
m = n // 1000 % 10
print('Unidade: {}'.format(u))
print('Dezena: {}'.format(d))
print('Centena: {}'.format(c))
print('Milhar: {}'.format(m))
