print('{} DESAFIO 27 {}'.format(('='*5), ('='*5)))
nome = str(input('Informe o nome completo: ')).title().strip().split()
print('Prmeiro nome: {}'.format(nome[0]))
print('Ultimo nome: {}'.format(nome[(len(nome)-1)]))
